package com.example.apiversioning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiVersioningDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiVersioningDemoApplication.class, args);
    }
}