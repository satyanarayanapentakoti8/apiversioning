package com.example.userservice.controller;

import com.example.userservice.dto.UserV1;
import com.example.userservice.dto.UserV2;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserUriController {

    @GetMapping("/v1/users")
    public UserV1 getUserV1() {
        return new UserV1("John Doe");
    }

    @GetMapping("/v2/users")
    public UserV2 getUserV2() {
        return new UserV2("John", "Doe");
    }
}